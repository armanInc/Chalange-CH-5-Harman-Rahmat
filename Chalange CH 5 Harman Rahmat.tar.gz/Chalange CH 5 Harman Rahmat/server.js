const express = require('express')
const app = express()
const fs = require('fs')
const { uuid } = require('uuidv4')
const bcrypt = require('bcrypt')
const cookieParser = require('cookie-parser')
const jwt = require('jsonwebtoken')
const isLoggedIn = require('./middleware/authMiddleware')
const { PassThrough } = require('stream')

//middleware cookieParser 
app.use(cookieParser())
app.set('view engine', 'ejs') // template view engine menggunakan ejs
// app.set('views', __dirname + '/views')
app.set('views', './public/views') // views nama folder dari si ejs 
// jika server js di dalam folder public gunakan  app.set('views', .'/views') 
// app.set('views', './views') 
// untuk share file secara public
app.use(express.static(__dirname + '/public'))
// suapaya aplikasi kita bisa menerima posting kita harus menggunakan middleware
// nah middle ware itu ada dua
//middleware untuk parsing body
app.use(express.urlencoded({ extended: true }))
// express.json supaya bisa baca json juga ya
app.use(express.json())


// console.log(__dirname)
// console.log(__dirname + '/public')
//routes
// nampilin data
// middleware isLoggedIn dari module middleware buatan  bukan dari npm 
// nah middleware panggil ditengah sini  , kenapa namanya middleware karna kita  manggil ditengah tengah antara function api nya yang mau kita panggil , yang mau kita gunakan functionya 
app.get('/', isLoggedIn, (req, res) => { // karna tadi di file autMiddleware ada next() berarti di a bakal lanjut ke function berikutnya yaitu memabaca  vari abel data , variabale dataparsed read sampai tutup kurun kurawal
    // jadi yang terjadi jika tidak dipanggil function next()  dia akan berhenti di isLoggedIn procesnya
    // kalo buat api sebenranya ada 3 (req, res, next) , karna next gak di pakai jadi gak di tulis , nah next itu dipakai cuman kalo temen temen pakai middle ware ata ubutuh function lainya ke middleware lainya 
    // jika tiak pakai encoding utf-8  bentuk masih buffer  
    const data = fs.readFileSync('./data/user.json', 'utf-8')
    const dataParsed = JSON.parse(data)
    // console.log(data)
    res.render('main', {
        PageTitle: "Main",
        //terus data langsung di pasasing ke dalam data jadi kalo saya mau ngambil data  main .ejs tinggal di kasih  <% data.forEach(item => { %>
        //     <tr>
        //     <td><%=  item.id %> </td>
        //     <td><%=  item.nama %> </td>
        //     <td><%=  item.genremusic %> </td>
        // </tr>
        // <% }) %>
        // terus di panggil dataParsed 
        data: dataParsed
    }) // res.render ngambil dua parameter pertama nama data kedua data yang mau di passing 
})

// add

app.get('/register', isLoggedIn, (req, res) => {
    res.render('register.ejs', {
        PageTitle: "register",
    }) // res.render ngambil dua parameter pertama nama data kedua data yang mau di passing 
})

// api untuk add data dari frontend 
// ada module baru namanya uuid untuk mengenerate 32 character  dia itu random  biasanya di gunakan di database jadi seakan akan sekarang punya database 
// npm install uuid
app.post('/register', (req, res) => {
    const { nama, email, password } = req.body // fungsi req.body buat nangkep data nama email password dari form yang dikirimkan ke front end
    const dataPost = fs.readFileSync('./data/user.json', 'utf-8')
    const dataParsedPost = JSON.parse(dataPost)
    hashedPassword = bcrypt.hashSync(password, 10)
    const salt = bcrypt.genSaltSync(10);
    const hashPassword = bcrypt.hashSync(password, salt);
    const newData = {
        // jadi kalo kita sekarang mau manggil id . kita tinggal panggil uuid
        id: uuid(),
        nama,
        email,
        password: hashPassword
        // hashedPassword
    }
    // console.log(req.body);
    // nambahin array baru kedalam data json yang udah di tambah tadi
    dataParsedPost.push(newData)
    //  habis itu tulis ulang file json pakai fs.writeFileSync
    fs.writeFileSync('./data/user.json', JSON.stringify(dataParsedPost, null, 4))
    // res.redirect itu maksa kita untuk pindah ke home nah home ada di slash ,
    // jika tidak di kasih res.redirect maaaka akaan terjadi error karna data seletah di add mau diapain lagi  file deprecated , tapi kal odi lait di home data sudah masuk
    res.redirect('/')
})
app.get('/edit', isLoggedIn, (req, res) => {
    const { id } = req.query
    const dataPost = fs.readFileSync('./data/data.json', 'utf-8')
    const dataParsedEdit = JSON.parse(dataPost)
    // kita kan udah pdat data nih dari query ?id=e1aeaaf1-0fe9-458e-9e6d-ea5c35bb57fd

    // nah id ini kita gunakan untuk mencari data di dalam json nya tapi supaya mempermudah edit ktia tambahin beberapa data dulu ya
    // console.log(id)
    const dataToEdit = dataParsedEdit.find((item) => {
        // balikin kasih kondisi dimana item.id itu diamana id sama dengan id
        return item.id == id
    })
    res.render('edit.ejs', {
        PageTitle: "Edit",
        data: dataToEdit,
    }) // res.render ngambil dua parameter pertama nama data kedua data yang mau di passing 
})


app.post('/edit', (req, res) => {
    const { id } = req.query
    // butuh nama , genre music karna si user butuh 2 pramater untuk di id nya
    const { nama, email, password } = req.body
    const dataPost = fs.readFileSync('./data/data.json', 'utf-8')
    const dataParsedEdit = JSON.parse(dataPost)
    const salt = bcrypt.genSaltSync(10);
    const hashPassword = bcrypt.hashSync(password, salt);
    // kita kan udah pdat data nih dari query ?id=e1aeaaf1-0fe9-458e-9e6d-ea5c35bb57fd

    // nah id ini kita gunakan untuk mencari data di dalam json nya tapi supaya mempermudah edit ktia tambahin beberapa data dulu ya
    // console.log(id)
    // udah gak butuh data lagi tapi butuh indexnya
    const dataToEditIndex = dataParsedEdit.findIndex((item) => {
        // balikin kasih kondisi dimana item.id itu diamana id sama dengan id
        return item.id == id;
    }) // kemudia setelah menemukan data ti index apa saya ingin me replace datanya jadi nunggu  hasil post dirkimin sama si user
    const dataToEdit = {
        id: id,
        nama: nama,
        email: email,
        password: hashPassword

    }

    dataParsedEdit[dataToEditIndex] = dataToEdit
    fs.writeFileSync('./data/data.json', JSON.stringify(dataParsedEdit, null, 4))
    // res.redirect itu maksa kita untuk pindah ke home nah home ada di slash ,
    // jika tidak di kasih res.redirect maaaka akaan terjadi error karna data seletah di add mau diapain lagi  file deprecated , tapi kal odi lait di home data sudah masuk
    res.redirect('/')
})

// app.get untuk hit api di browser dengan mengetik url 


app.post('/delete', (req, res) => {
    const { id } = req.query

    const dataPost = fs.readFileSync('./data/user.json', 'utf-8')
    const dataParsedEdit = JSON.parse(dataPost)
    // kita kan udah pdat data nih dari query ?id=e1aeaaf1-0fe9-458e-9e6d-ea5c35bb57fd

    // nah id ini kita gunakan untuk mencari data di dalam json nya tapi supaya mempermudah edit ktia tambahin beberapa data dulu ya
    // console.log(id)
    // udah gak butuh data lagi tapi butuh indexnya 
    const deletedList = dataParsedEdit.filter((item) => {
        // balikin kasih kondisi dimana item.id itu diamana id sama dengan id
        // kondisi tidak sama dengan !== jadi id tidak sama dengan isi array maka tidak di masukkan ke array baru untu k di fswrite lalu tidak muncul di browser apa yang udanh di hapu fungsi dari filter membuat array baru 
        return item.id != id
        //jika pakai === maka id dari si data tidak terhapus karn masuk ke filter buat array baru dan fs write untuk menampilkan data  di post   jika pakai tidak sama dengan id  maka id yang ada di req query tidak sma dengan id yang dihapus lalu id  maka id yang di hapus tidak masuk ke dalam filter array  karna tidak sama dengan isi dari index array    dari id yang mau di hapus   maka tidak masuk kedalam filter
    }) // kemudia setelah menemukan data ti index apa saya ingin me replace datanya jadi nunggu  hasil post dirkimin sama si user
    fs.writeFileSync('./data/user.json', JSON.stringify(deletedList, null, 4))
    // res.redirect itu maksa kita untuk pindah ke home nah home ada di slash ,
    // jika tidak di kasih res.redirect maaaka akaan terjadi error karna data seletah di add mau diapain lagi  file deprecated , tapi kal odi lait di home data sudah masuk
    console.log(deletedList)
    res.redirect('/')
})

// cara kerja dari halaman login ini buat verifikasi user
app.get('/login', (req, res) => {
    const { status } = req.query // untuk ngebaca status dari query login
    res.render('login', {
        status
    })
})

app.post('/login', (req, res) => {
    const { email, password } = req.body
    // untuk membaca isi dari file user .json
    // kalo ada yang login dia bakal baca si data user ada siapa aja yang login
    const data = JSON.parse(fs.readFileSync('./data/user.json', 'utf-8'))

    // const dataPost = fs.readFileSync('./data/user.json', 'utf-8')
    // const dataParsedPost = JSON.parse(dataPost)
    // const salt = bcrypt.genSaltSync(10);
    // const hashPassword = bcrypt.hashSync(password, salt);
    const userMatch = data.find((item) => item.email === email) // mau nyari email yang 
    // const newData = {
    //     // jadi kalo kita sekarang mau manggil id . kita tinggal panggil uuid
    //     email,
    //     password: hashPassword
    //     // hashedPassword
    // }
    // dataParsedPost[userMatch] = newData
    // // fs.readFileSync('./data/user.json', JSON.stringify(dataParsedPost, null, 4))
    // console.log(dataParsedPost)
    // const compareBcrypt = bcrypt.compareSync(password);
    // dataParsedPost.push(newData)
    //    misalkan dia error misalkan email dia gak ada
    //    maksud dari tanda seru ini di dalam if ini 
    //    jika kondisi sama kaya gini if(!userMatch) === null atau userMatch === undefined atau userMatch === false
    if (!userMatch) { // jadi kalo dia  usermatch nilainya negatif  balik lagi ke /login dengan res.redirect
        res.redirect('/login?status=emailnotfound')
    } else { // kalo email ketemu mau cek lagi si password itu sama gak sama  yang di input sama si user  . nilai data sema degan yang ada di data json kita
        if (password === userMatch.password) {
            // bcrypt.compare(password, hashPassword, function (err, result) {
            //     if (result === true) {
            //         // const token = jwt.sign({ // cara ngunci data jwt.sign , data di kunci agar tidak di acak acak sama orang
            //         //     email: userMatch.email,
            //         //     id: userMatch.id,

            //         // }, 'secret', { // parameter kedua adalah kuncinya , kunci ini di pakai untuk si data itu bebas kunci nya lebih bagus lagi kunci itu gabungan dari angka huruf dan character
            //         //     expiresIn: 60 * 60 * 24 // ini artinta 1 hari 60 detik * 60 minute * 24 jam ada masa waktu nya  klo toke satuan nya detik , beda dengan cookie satuanya milie second kalo mau gak perlu
            //         // }) 
            //         // res.cookie('jwt', token, { maxAge: 1000 * 60 * 60 * 24 },)
            //     }
            // });
            const token = jwt.sign({ // cara ngunci data jwt.sign , data di kunci agar tidak di acak acak sama orang
                email: userMatch.email,
                id: userMatch.id,

            }, 'secret', { // parameter kedua adalah kuncinya , kunci ini di pakai untuk si data itu bebas kunci nya lebih bagus lagi kunci itu gabungan dari angka huruf dan character
                expiresIn: 60 * 60 * 24 // ini artinta 1 hari 60 detik * 60 minute * 24 jam ada masa waktu nya  klo toke satuan nya detik , beda dengan cookie satuanya milie second kalo mau gak perlu
            })
            // console.log(toke)  //  conosle.log  token untuk mendapatkan token di console saat si user login
            // kalo udah dapet tokenya kirim ke front end pakai res.cookie parameter pertama key nya , keyna namanya bebas  , parameter kedua data yang mau kita kirmin toke nya , parameter ketiga masa aktif nya  token
            res.cookie('jwt', token, { maxAge: 1000 * 60 * 60 * 24 }) // kasih res.redirect jadi kalo dia berhasil login , saya akan ngarahin dia ke halaman home halama nmainya
            // kalo mau si token selalu aktif jadi user gak perlu login ulang lagi expiresIn: 60 * 60 * 24  di hapus aja
            // cara ngebuka jwt nya kita panggil jwt.verify , jadi untuk buka token tadi kita panggill dengan jwt verify yang tadi bentuk data email dan data id terus di kunci jadi bentuk kaya gini eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
            // yg tadi bentuk kaya gini tokennya eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c terus di buka lagi kncinya
            //jwt.verify() terus panggil token yang mau di buka kuncinya  , param eter kedua kunci 'secret' , call back errr, decodedTOken , decoded token adalah yang kita buka kuncinya
            // jwt.verify(token, 'secret', (err, decodedToken) => { // jwt.verify gak dibutuhuin kalo di login  dia di butuhin  untuk cek apada apa enggak tokenya di middleware
            //     console.log(decodedToken) // setelah di console log hasil jadi ini di buat kapan  iat: 1642992419, , yang angka angka ini javascript date bentuk number   ini masa aktif habis kapan exp: 1643078819
            // })
            // jadi di  console.log(decodedToken)  untuk melihat isi dari token nya apa sih

            res.redirect('/') // jadi kalo berhasil login saya mau balikin dia ke halaman home atau halaman mainnya
        } else {
            res.redirect('/login?status=wrongpassword')
        }
    }
})
// middle ware di butuhkan untuk ngechek apakah si user ini sedang login apa enggak


// app.post('/login', (req, res) => {
//     const { email, password } = req.b ody
//     // untuk membaca isi dari file user .json
//     const dataPost = fs.readFileSync('./data/user.json', 'utf-8')
//     const dataParseLogin = JSON.parse(dataPost)
//     const userMatch = dataParseLogin.find((item) => {
//         item.email == email
//     })

//     if (!userMatch) {
//         res.redirect('/login?status=emailnotfound') // kalo email gak ketemu balikin ke login isinya query string lalu kasih status email notfound
//     } else { // jika password sama dengan data yang ada di data json maka  dia bakal lanjut
//         if (password === userMatch.password) {
//             const token = jwt.sign({   // jadi di sini ingin mengunci data object
//                 email: userMatch.email, // untuk  mengunci emailnya 
//                 id: userMatch.id  //untuk mengunci user id
//             }, 'Kunc1dancharacter', { // lalau masukin lagi parameter expiresIn
//                 expiresIn: 60 * 60 * 24  // ini artinta 1 hari
//             }) // di parameter kedua ini ada lah kunci nya
//             console.log(token)

//             //res.send
//         } else { // tapi kalo email gak sama dia bakal redirect dengan pesan error berbeda
//             res.redirect('/login?status=wrongpassword')
//         }
//     }
// })





app.get('/set-cookies', (req, res) => {
    // parameter pertama Set-Cookie artinya saya ingin mengasih cookie ke client kedalam browser yg lain
    // parameter kedua key sama value dari si cookienya , saya pengen ngasih user id = 1
    // cara vanilla
    // res.setHeader('Set-Cookie', 'userId=1') // kal oudah ad amiddle ware cookie parse r cara gk pakai res.setHeader key dapet dari userId lal uvalue 1 sesuai yang di passing di parameter usserId=1
    // cara modul cookieParser
    res.cookie('userId', 1)   // maxAge 1000 milisecond * 60 detik * 60 detik * 24 jam
    res.cookie('username', "Harman", { maxAge: 1000 * 60 * 60 * 24 }) // di parameter ketiga  cara mengatur expires cookie menggunakan maxAge 
    // bedanya session dengan yang ada masa waktunya  kalo browser di close userId hilang 

    // lalu kalo kita get lagi kita mendapatkan dua value yang kita passing tadi
    // jika tidak mengaktifkan perintah lag seperti res.json  atau res.redirect('/') setelah res.setheader  maka akan terjadi error
    // jika mau data permanent max age jangan disetting jadi session yg ada di max age gk menghilang 
    res.json({
        message: "anda mendapat cookie" // untuk mengakses di console bisa mengetikan document.cookie untuk mendapatkan cookienya
    })
})

// untuk logout hapus cookie yang tadi 


app.post('/logout', (req, res) => {
    res.cookie('jwt', { maxAge: 1 }) // pada parameter kedua di kasih string ' ' kosong berarti kita menghapus tokenya  maxAge itu 1 miliesecond
    res.redirect('/login')
})


// app.get('/registerfromout', isLoggedIn, (req, res) => {
//     res.render('registerfromOut.ejs', {
//         PageTitle: "registerFromOut",
//     }) // res.render ngambil dua parameter pertama nama data kedua data yang mau di passing 
// })

// app.post('/registerfromout', (req, res) => {

//     const { nama, email, password } = req.body // fungsi req.body buat nangkep data nama email password dari form yang dikirimkan ke front end
//     const dataPost = fs.readFileSync('./data/data.json', 'utf-8')
//     const dataParsedPost = JSON.parse(dataPost)
//     // hashedPassword = bcrypt.hashSync(password, 10)
//     const salt = bcrypt.genSaltSync(10);
//     const hashPassword = bcrypt.hashSync(password, salt);
//     const newData = {
//         // jadi kalo kita sekarang mau manggil id . kita tinggal panggil uuid
//         id: uuid(),
//         nama,
//         email,
//         password: hashPassword
//         // hashedPassword
//     }
//     // console.log(req.body);
//     // nambahin array baru kedalam data json yang udah di tambah tadi
//     dataParsedPost.push(newData)
//     //  habis itu tulis ulang file json pakai fs.writeFileSync
//     fs.writeFileSync('./data/data.json', JSON.stringify(dataParsedPost, null, 4))
//     // res.redirect itu maksa kita untuk pindah ke home nah home ada di slash ,
//     // jika tidak di kasih res.redirect maaaka akaan terjadi error karna data seletah di add mau diapain lagi  file deprecated , tapi kal odi lait di home data sudah masuk
//     res.redirect('/')
// })


// cara baca cookie yang ada di user 
// jadi ketika kita ngepost sesuatu kedalam server cookie ini automatis langsung dikirimin juga
// jadi ketika kita sudah ada cookie disini web itu mau get, mau post, mau put, automatis si cookie akan dikirimin lagi kedalam api nya  

app.get('/get-cookies', (req, res) => { // jadi kalo kita mau dapetin data yang udah di simpan di browser nya si client cara nya (req, res) => {}
    console.log(req.cookies)
    //res.json cookies:req.cookies untuk balikin cookiesnya
    res.json({ cookies: req.cookies })
})
// lalu di cookie juga ada parameter lagi yang namanya expires
// jadi di expires dalam waktu misalkan 1 menit cookie bakal hilang atau dalam waktu 1 jam cookie bakal hilan
// misalkan di set expires cookie user login masa aktif cuman 1 hari , jadi kalo udah satu hari dia harus login ulang 
// kalo hash data gak bisa dibuka lagi , kalo token datanya bisa di buka lagi

// jsonWebToken 
// salah satu media verifikasi login adalah json webtoken
// JsonWebToken adalah data yang kita kunci , dan kta juga harus punya key untuk membukanya unutuk kunci data ini kita butuh yang namanya key

//refrence : https://jwt.io/ contoh daya yang udah di kunci   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
// kalo hash data tidak bisa di buka lagi
// kalo token datanya bisa di buka lagi
// key bebas dan kunci ini bisa untuk mengunci ataupun membuka

// algoritma kunci data pakai HS256 ,  dan tyo JWT


const PORT = 3000
app.listen(PORT, () => {
    console.log(`Server is running at port ${PORT} `)
}) 