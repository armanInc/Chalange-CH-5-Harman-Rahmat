var numbers = [1, 3, 4, 6, 7]

var greaterThanSeven = numbers.filter(function (number) {
    return number !== 7;
});

console.log(greaterThanSeven);