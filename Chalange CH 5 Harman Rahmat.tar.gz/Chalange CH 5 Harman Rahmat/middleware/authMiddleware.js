const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')
// untuk membaca token , berartikan harus ngebaca cookie si user
const isLoggedIn = (req, res, next) => {
    // cara yang lain panggil const {jwt} kal pake cara ini nanti bentrok sam si module nya const jwt = require('jsonwebtoken')
    const token = req.cookies.jwt  // kenapa jwt karna pake name nya jwt , jadi saya mau manggil cookie nama key nya itu jwt
    // console.log(token) // console.log(token) untuk melihat apakah dapet tokenya gak?  dari cookies jwt
    // jadi kalo token nya udah kebaca proses selanjutnya adalah
    // kalo tokenya ada berarti user login , kalo tokenya gk ada berarti user gak login

    if (token) { // cara cek token nya bener gak pake jwt.verify
        jwt.verify(token, 'secret', (err, decodedToken) => {
            // jwt.verify gak dibutuhuin kalo di login  dia di butuhin  untuk cek bener apa engga tokenya di middleware  
            // console.log(decodedToken) // setelah di console log hasil jadi ini di buat kapan  iat: 1642992419, , yang angka angka ini javascript date bentuk number   ini masa aktif habis kapan exp: 1643078819

            // butuh kondisi lagi kalo ternyata tokenya error atau udah expires 
            if (err) { // klao tukan udah gak falid tadi kan kita nyeting tokenya satu hari  jadi kal oduah lebih dari 1 hari berarti tokenya udah habis masa waktunya, dia bakal masuk kedalam error   
                res.locals.user = null // misalkan tokennya error jadi bakal ngapus data user nilainya jadi null , jadi user kosong 
                res.redirect('/login') // jadi kalo misalkan dia error bakal ngarahin dia ke res.redirect('/login)
            } else { // kalo dia berhasil bakal ngelanjutin dia ke proses berikutnya 
                // kalo berhasil console.log(decodedToken)
                res.locals.user = decodedToken.email // res.locals.user seperit kita ngasih variable global ke ejs

                // jadi res.locals ini dia bisa akses data user dimanapun di berada modulenya
                // isi data user itu apa email orang yang lagi login 
                console.log(decodedToken)

                // bcrypt.compareSync(password, hashPassword)
                next() // ke funtion berikutnya , adalah halaman loginya 
            }
        })
        next() // jadi next ini kalo misalkan dia lagi ada tokenya dia lanjut ke proses render halaman home  , app.get('/') 
    } else { // kalo user gak login berarti balikin lagi ke proses login 
        res.locals.user = null // kalo mislakan tokenya gk ada user dibikin kosong juga karna kalo tokenya error berarti gk ada yang login makanya user di hapus dari global
        res.redirect('/login')// kalo tokenya gk ada berarti dia balikin lagi ke halaman login

    }

    // jadi kalo next ini kalo proses udah selesai berarti dia langsung next ke proses berikutnya

    // lalu cek kasih kondisi kalo user ada berarti lagi gak login , kalo user 

}

module.exports = isLoggedIn